#!/usr/bin/env python
import sys, os, time
import tweepy
keys = dict(
consumer_key='_YOUR_CONSUMER_KEY',
consumer_secret='_YOUR_SECRET_KEY',
access_token='_YOUR_ACCESS_TOKEN', 
access_token_secret='_YOUR_ACCESS_TOKEN_SECRET'
)

user = "@YOUR_USERNAME"

auth = tweepy.OAuthHandler(keys['consumer_key'], keys['consumer_secret'])
auth.set_access_token(keys['access_token'], keys['access_token_secret'])
api = tweepy.API(auth)

def tweet():
	message=input("tweet: ")
	api.update_status(message)
	time.sleep(1000)
if __name__ == "__main__":
	while 1:
		tweet()